$(function () {
    let pathname = window.location.pathname,
        hurl = pathname.indexOf('/en') === -1 ? '/component/head/head.html' : '/component/head/head_en.html',
        furl = pathname.indexOf('/en') === -1 ? '/component/foot/foot.html' : '/component/foot/foot_en.html',
        aurl = pathname.indexOf('/en') === -1 ? '/component/aside/aside.html' : '/component/aside/aside_en.html';

    $('#Head').load(hurl,function(){

        $('.lq_head_item>a').each(function(i,item){
            // console.log(item.href , window.location.origin + pathname)
            if(item.href === location.origin + pathname){
                $(item).addClass('lq_head_active')
            }
            
        })
        if(pathname === '/' || pathname === '/en/'){
            $('.lq_head_item').eq(0).children('a').addClass('lq_head_active')
        }
        if(pathname === '/detail' || pathname === '/en/detail'){
            $('.lq_head_item').eq(2).children('a').addClass('lq_head_active')
        }
        if(pathname === '/newsDetail' || pathname === '/en/newsDetail'){
            $('.lq_head_item').eq(7).children('a').addClass('lq_head_active')
        }
        if(location.href === location.origin + '/handle?type=1' || location.href === location.origin + '/en/handle?type=1'){
            $('.lq_head_active').removeClass('lq_head_active')
            $('.lq_head_item').eq(4).children('a').addClass('lq_head_active')
        }

        let width = document.body.offsetWidth;
        
        if(width > 766){
            $('.lq_head_item').hover(function(){
                $(this).find('.lq_head_exc').stop().slideToggle();
            })
        }

        if(width < 766){
            $('.lq_head_menu').click(function(){
                $('.lq_head_middle').slideDown();
            })
            $('.lq_head_middle').click(function(){
                $(this).slideUp();
            })
            $('.lq_head_middel>a').click(function(){
                e.stopPropagation();
            })
        }


        $('.head_lang_m').click(function(){
            if(pathname.indexOf('/en') > -1){
                window.location.href = pathname.replace('/en','') + location.search;
            }else{
                window.location.href = '/en'+pathname + location.search;
            }
        })
        $('.head_lang>a:first-child').click(function(){
            if(pathname.indexOf('/en') > -1){
                window.location.href = pathname.replace('/en','') + location.search;
            }
        })
        $('.head_lang>a:last-child').click(function(){
            if(pathname.indexOf('/en') === -1){
                window.location.href = '/en'+pathname + location.search;
            }
        })

        $(document).scroll(function(){
            var scroH = $(document).scrollTop();  //滚动高度
            if(scroH >= 200){
                $('.lq_head').addClass('lq_head_white');
            }else{
                $('.lq_head').removeClass('lq_head_white');
            }
        })

    });

    $('#Foot').load(furl,function(){
        let width = document.body.offsetWidth;

        if(width < 766){
            $('.lq_foot_item').click(function(){
                $(this).find('div').slideToggle();
            })
            $('.lq_foot_item>div>a').click(function(e){
                e.stopPropagation();
            })
        }
    });

    let width = document.body.offsetWidth;
    if(width > 766){
        $.post('/aside',function(data){
            if(data.data.is_open){
                $('#Aside').load(aurl,function(){
                    $('.lq_aside>i').click(function(){
                        $('.lq_aside').remove()
                    })
                });
            }
        })

    }


})

function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
}